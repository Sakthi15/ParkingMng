﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcDemoProject.Models
{
    public class Prices
    {
        [Required]
        public string VechileType { get; set; }
        [Required]
        public Nullable<int> Duration { get; set; }
        public Nullable<int> Price { get; set; }
    }
}