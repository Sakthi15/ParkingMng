﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcDemoProject.Models
{
    public class UserData
    {
        [Required]
        public string Location { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public string EntryDate { get; set; }
        [Required]
        [DataType(DataType.Time)]
        public string EntryTime { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public string ExitDate { get; set; }
        [Required]
        [DataType(DataType.Time)]
        public string ExitTime { get; set; }
        [Required]
        public string VehicleNo { get; set; }
        
    }
}