﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcDemoProject.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage ="Email can't be left blank")]
        [EmailAddress]
        [Display(Name = "Email: ")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please Enter Your Password")]
        [DataType(DataType.Password)]
        [Display(Name = "Password: ")]
        public string Password { get; set; }


        [Required(ErrorMessage = "Please Enter Your Password")]
        [DataType(DataType.Password)]
        [StringLength(18, ErrorMessage = "The password must be atleast 3 characters long", MinimumLength = 3)]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = "Please Enter Your ConfirmPassword")]
        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "Password is not identical")]
        public string ConfirmPassword { get; set; }
    }
}