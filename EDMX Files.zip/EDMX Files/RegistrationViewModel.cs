﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcDemoProject.Models
{
    public class RegistrationViewModel
    {
        
        [Required(ErrorMessage ="Name can't be left blank")]
        [Display(Name = "Name: ")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email can't be left blank")]
        [EmailAddress]
        [StringLength(150)]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email: ")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Address can't be left blank")]
        [Display(Name = "Address: ")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Password can't be left blank")]
        [DataType(DataType.Password)]
        [StringLength(150, MinimumLength = 6)]
        [Display(Name = "Password: ")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm Password can't be left blank")]
        [DataType(DataType.Password)]
        [Compare("Password",ErrorMessage ="Password is not identical")]
        [StringLength(150, MinimumLength = 6)]
        [Display(Name = "Confirm Password: ")]
        public string ConfirmPassword { get; set; }
    }
}