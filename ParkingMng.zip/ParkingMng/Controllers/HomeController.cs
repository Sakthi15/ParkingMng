﻿using MvcDemoProject.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MvcDemoProject.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult ContactUs()
        {
            return View();
        }
        // GET: Home
        public ActionResult AboutUs()
        {

            return View();
        }
        // GET: UserDetail
       
            public ActionResult Payment()
        {
            return View();
        }

        
        // GET:Login 
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        //Post:Login 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginViewModel LoginViewModel)
            
        {
            if (LoginViewModel.Email != null && LoginViewModel.Password != null)
            {
                if (IsAuthenitcatedUser(LoginViewModel.Email, LoginViewModel.Password))
                {

                    Session["Username"] = LoginViewModel.Email.ToString();

                    //MVC and Login Authentication
                    FormsAuthentication.SetAuthCookie(LoginViewModel.Email, false);
                    //TempData["LoginSuccessMessage"] = "<script>alert('Login Sucessfull !!')</script>";
                    return RedirectToAction("Update", "Users_Data");
                }
                else
                {
                    ModelState.AddModelError("", "Your credentail is incorrect");
                }
            }
            else
            {
                ModelState.AddModelError("", "Please fill the required field");
            }
            return View(LoginViewModel);
        }
        // GET:Register return view
        [HttpGet]
        public ActionResult UserRegistration()
        {
            return View();
        }
        // Post:Register 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserRegistration(RegistrationViewModel RegistrationViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!IsEmailExist(RegistrationViewModel.Email))
                    {
                        using (DemoDataBaseEntities db = new DemoDataBaseEntities())
                        {
                            UserDetail userobj = new UserDetail
                            {
                                Email = RegistrationViewModel.Email,
                                Name = RegistrationViewModel.Name,
                                //for encryption you should use a strong and secure Algorithm
                                // I'm simply using Base64 for explanation purpose
                                Encryptedpassword = GetMD5(RegistrationViewModel.Password),
                                Address = RegistrationViewModel.Address
                            };
                            db.UserDetails.Add(userobj);
                            if (db.SaveChanges() > 0)
                            {
                                //Set MVC and Login Authentication
                                FormsAuthentication.SetAuthCookie(RegistrationViewModel.Email, false);
                                return RedirectToAction("Login", "Home");
                            }
                            else
                            {
                                ModelState.AddModelError("", "Something went wrong please try again later!");
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "Email already exist please try with diffrent one!");
                    }



                }
                else
                {
                    ModelState.AddModelError("", "Model is Invalid");
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("", e.Message);
            }
            return View();
        }
        public ActionResult SignOut()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Login", "Home");
        }

        private bool IsEmailExist(string email)
        {
            bool IsEmailExist = false;
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                int count = db.UserDetails.Where(a => a.Email == email).Count();
                if (count > 0)
                {
                    IsEmailExist = true;
                }
            }
            return IsEmailExist;
        }
        private bool IsAuthenitcatedUser(string email, string password)
        {
            var encryptpassowrd = GetMD5(password);
            bool IsValid = false;
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                int count = db.UserDetails.Where(a => a.Email == email && a.Encryptedpassword == encryptpassowrd).Count();
                if (count > 0)
                {
                    IsValid = true;
                }
            }
            return IsValid;
        }
        [HttpGet]
        public ActionResult Changepassword()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Changepassword(LoginViewModel LoginViewModel)
        {
           
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                if (IsAuthenitcatedUser(LoginViewModel.Email, LoginViewModel.Password))
                {

                    string connectionString = @"data source=WIN-2P8QAF1IA5A\SQLEXPRESS;initial catalog=KeytoSuccess;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework";



                    using (SqlConnection sqlCon = new SqlConnection(connectionString))
                    {
                        sqlCon.Open();
                        string query = "UPDATE UserDetails SET Encryptedpassword = @Encryptedpassword  WHere Email = @Email";
                        SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                        sqlCmd.Parameters.AddWithValue("@Email", LoginViewModel.Email);
                        sqlCmd.Parameters.AddWithValue("@Encryptedpassword", GetMD5(LoginViewModel.NewPassword));
                        sqlCmd.ExecuteNonQuery();
                    }
                    return RedirectToAction("SignOut");
                }
                else
                {
                    ModelState.AddModelError("", "Your credentail is incorrect");
                }
                return View(LoginViewModel);
            }
        }
       
       

       

        private static string GetMD5(string str)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] fromData = Encoding.UTF8.GetBytes(str);
            byte[] targetData = md5.ComputeHash(fromData);
            string byte2String = null;

            for (int i = 0; i < targetData.Length; i++)
            {
                byte2String += targetData[i].ToString("x2");

            }
            return byte2String;
        }

    }
}