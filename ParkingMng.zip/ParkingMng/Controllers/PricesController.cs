﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MvcDemoProject.Models;

namespace MvcDemoProject.Controllers
{
    public class PricesController : Controller
    {
        private DemoDataBaseEntities db = new DemoDataBaseEntities();

        // GET: Prices
        public ActionResult Index()
        {
            return View(db.UserDetails.ToList());
        }

        // GET: Prices/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail price = db.UserDetails.Find(id);
            if (price == null)
            {
                return HttpNotFound();
            }
            return View(price);
        }

        // GET: Prices/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Prices/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,VechileType,Duration,Price")] UserDetail price)
        {
            return View(price);
        }

        [HttpGet]
        public ActionResult Update()
        {

            return View();
        }

        [HttpPost]

        public ActionResult Update(Prices price)
        {
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {


                    string connectionString = @"data source=WIN-2P8QAF1IA5A\SQLEXPRESS;initial catalog=KeytoSuccess;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework";


                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    //if (IsUserExist(price.VehicleNo))
                    //{
                        if (price.VechileType == "Two_wheeler" && price.Duration == 1)
                        {
                            ViewBag.Cost = "Rs.10";
                            sqlCon.Open();
                            string query = "UPDATE UserDetails SET VechileType= @VechileType, Duration = @Duration,Price = 10  WHere Email = @Email";
                            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                            sqlCmd.Parameters.AddWithValue("@VechileType", price.VechileType);
                            sqlCmd.Parameters.AddWithValue("@Duration", price.Duration);
                            sqlCmd.Parameters.AddWithValue("@Email", Session["Username"]);
                            sqlCmd.ExecuteNonQuery();

                            return RedirectToAction("Payment", "Home");
                        }
                        else if (price.VechileType == "Two_wheeler" && price.Duration == 2)
                        {
                            ViewBag.Cost = "Rs.20";
                            sqlCon.Open();
                            string query = "UPDATE UserDetails SET VechileType= @VechileType, Duration = @Duration,Price = 20  WHere Email = @Email";
                            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                            sqlCmd.Parameters.AddWithValue("@VechileType", price.VechileType);
                            sqlCmd.Parameters.AddWithValue("@Duration", price.Duration);
                            sqlCmd.Parameters.AddWithValue("@Email", Session["Username"]);
                            sqlCmd.ExecuteNonQuery();

                            return RedirectToAction("Payment", "Home");
                        }
                        else if (price.VechileType == "Two_wheeler" && (price.Duration > 2 && price.Duration <= 12))
                        {
                            ViewBag.Cost = "Rs.50";
                            sqlCon.Open();
                            string query = "UPDATE UserDetails SET VechileType= @VechileType, Duration = @Duration,Price = 50  WHere Email = @Email";
                            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                            sqlCmd.Parameters.AddWithValue("@VechileType", price.VechileType);
                            sqlCmd.Parameters.AddWithValue("@Duration", price.Duration);
                            sqlCmd.Parameters.AddWithValue("@Email", Session["Username"]);
                            sqlCmd.ExecuteNonQuery();

                            return RedirectToAction("Payment", "Home");
                        }
                        else if (price.VechileType == "Two_wheeler" &&( price.Duration > 12 && price.Duration <= 24))
                        {
                            ViewBag.Cost = "Rs.90";
                            sqlCon.Open();
                            string query = "UPDATE UserDetails SET VechileType= @VechileType, Duration = @Duration,Price = 90  WHere Email = @Email";
                            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                            sqlCmd.Parameters.AddWithValue("@VechileType", price.VechileType);
                            sqlCmd.Parameters.AddWithValue("@Duration", price.Duration);
                            sqlCmd.Parameters.AddWithValue("@Email", Session["Username"]);
                            sqlCmd.ExecuteNonQuery();

                            return RedirectToAction("Payment", "Home");
                        }

                        else if (price.VechileType == "Four_wheeler" && price.Duration == 1)
                        {
                            ViewBag.Cost = "Rs.30";
                            sqlCon.Open();
                            string query = "UPDATE UserDetails SET VechileType= @VechileType, Duration = @Duration,Price = 30  WHere Email = @Email";
                            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                            sqlCmd.Parameters.AddWithValue("@VechileType", price.VechileType);
                            sqlCmd.Parameters.AddWithValue("@Duration", price.Duration);
                            sqlCmd.Parameters.AddWithValue("@Email", Session["Username"]);
                            sqlCmd.ExecuteNonQuery();

                            return RedirectToAction("Payment", "Home");
                        }
                        else if (price.VechileType == "Four_wheeler" && price.Duration == 2)
                        {
                            ViewBag.Cost = "Rs.60";
                            sqlCon.Open();
                            string query = "UPDATE UserDetails SET VechileType= @VechileType, Duration = @Duration,Price = 60  WHere Email = @Email";
                            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                            sqlCmd.Parameters.AddWithValue("@VechileType", price.VechileType);
                            sqlCmd.Parameters.AddWithValue("@Duration", price.Duration);
                            sqlCmd.Parameters.AddWithValue("@Email", Session["Username"]);
                            sqlCmd.ExecuteNonQuery();

                            return RedirectToAction("Payment", "Home");
                        }
                        else if (price.VechileType == "Four_wheeler" && (price.Duration > 2 && price.Duration <= 12))
                        {
                            ViewBag.Cost = "Rs.150";
                            sqlCon.Open();
                            string query = "UPDATE UserDetails SET VechileType= @VechileType, Duration = @Duration,Price = 150  WHere Email = @Email";
                            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                            sqlCmd.Parameters.AddWithValue("@VechileType", price.VechileType);
                            sqlCmd.Parameters.AddWithValue("@Duration", price.Duration);
                            sqlCmd.Parameters.AddWithValue("@Email", Session["Username"]);
                            sqlCmd.ExecuteNonQuery();

                            return RedirectToAction("Payment", "Home");
                        }
                        else if (price.VechileType == "Four_wheeler" && (price.Duration > 12 && price.Duration <= 24))
                        {
                            ViewBag.Cost = "Rs.200";
                            sqlCon.Open();
                            string query = "UPDATE UserDetails SET VechileType= @VechileType, Duration = @Duration,Price = 200  WHere Email = @Email";
                            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                            sqlCmd.Parameters.AddWithValue("@VechileType", price.VechileType);
                            sqlCmd.Parameters.AddWithValue("@Duration", price.Duration);
                            sqlCmd.Parameters.AddWithValue("@Email", Session["Username"]);
                            sqlCmd.ExecuteNonQuery();

                            return RedirectToAction("Payment", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Please check your vehicle type and duration");

                    }

                }
                
            }
            return View(price);
        }


        // GET: Prices/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail price = db.UserDetails.Find(id);
            if (price == null)
            {
                return HttpNotFound();
            }
            return View(price);
        }

        // POST: Prices/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,VechileType,Duration,Price1")] UserDetail price)
        {
            if (ModelState.IsValid)
            {
                db.Entry(price).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(price);
        }

        // GET: Prices/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail price = db.UserDetails.Find(id);
            if (price == null)
            {
                return HttpNotFound();
            }
            return View(price);
        }

        // POST: Prices/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            UserDetail price = db.UserDetails.Find(id);
            db.UserDetails.Remove(price);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        private bool IsUserExist(string user)
        {
            bool IsUserExist = false;
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                int count = db.UserDetails.Where(a => a.VehicleNo == user).Count();
                if (count > 0)
                {
                    IsUserExist = true;
                }
            }
            return IsUserExist;
        }
    }
}
