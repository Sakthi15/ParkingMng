﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MvcDemoProject.Models;

namespace MvcDemoProject.Controllers
{
    public class Users_DataController : Controller
    {
        private DemoDataBaseEntities db = new DemoDataBaseEntities();

        // GET: Users_Data
        public ActionResult Index()
        {
            return View(db.UserDetails.ToList());
        }

        // GET: Users_Data/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail users_Data = db.UserDetails.Find(id);
            if (users_Data == null)
            {
                return HttpNotFound();
            }
            return View(users_Data);
        }

        // GET: Users_Data/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Users_Data/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(UserData users_Data)
        {
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                if (!IsUserExist(users_Data.VehicleNo))
                {
                    string connectionString = @"data source=WIN-2P8QAF1IA5A\SQLEXPRESS;initial catalog=KeytoSuccess;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework";

                    using (SqlConnection sqlCon = new SqlConnection(connectionString))
                    {

                        sqlCon.Open();
                        string query = "insert into UserDetails(Location,EntryDate,EntryTime,ExitDate,ExitTime,VehicleNo) values(@Location,@EntryDate,@EntryTime,@ExitDate,@ExitTime,@VehicleNo)";
                        SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                        sqlCmd.Parameters.AddWithValue("@Location", users_Data.Location);
                        sqlCmd.Parameters.AddWithValue("@EntryTime", users_Data.EntryTime);
                        sqlCmd.Parameters.AddWithValue("@EntryDate", users_Data.EntryDate);
                        sqlCmd.Parameters.AddWithValue("@ExitDate", users_Data.ExitDate);
                        sqlCmd.Parameters.AddWithValue("@ExitTime", users_Data.ExitTime);
                        sqlCmd.Parameters.AddWithValue("@VehicleNo", users_Data.VehicleNo);

                        sqlCmd.ExecuteNonQuery();
                        return RedirectToAction("Update", "Prices");
                    }
                }


                else
                {
                    ModelState.AddModelError("", "Something went wrong!");
                }

                return View(users_Data);
            }
        }
        [HttpGet]
        public ActionResult Update()
        {
            
            return View();
        }

        [HttpPost]

        public ActionResult Update(UserData users_Data, FormCollection fobj)
        {

            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                if ((users_Data.Location == "HCL IT City"|| users_Data.Location =="Alambagh"|| users_Data.Location == "Charbagh"|| users_Data.Location == "Aliganj" || users_Data.Location == "Nehru Nagar")&& users_Data.EntryDate != null&& users_Data.EntryTime != null&& users_Data.ExitDate != null&& users_Data.ExitTime != null&& users_Data.VehicleNo != null)
                {
                   


                            //if (IsEmailExist(users_Data.Email))
                            //    {
                            string connectionString = @"data source=WIN-2P8QAF1IA5A\SQLEXPRESS;initial catalog=KeytoSuccess;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework";


                    using (SqlConnection sqlCon = new SqlConnection(connectionString))
                    {

                        sqlCon.Open();
                        string query = "UPDATE UserDetails SET Location = @Location,EntryDate = @EntryDate,EntryTime = @EntryTime,ExitDate=@ExitDate,ExitTime = @ExitTime,VehicleNo=@VehicleNo,Email =@Email  WHere Email = @Email";
                        SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                        sqlCmd.Parameters.AddWithValue("@Email", Session["Username"]);
                        sqlCmd.Parameters.AddWithValue("@Location", users_Data.Location);
                        sqlCmd.Parameters.AddWithValue("@EntryTime", users_Data.EntryTime);
                        sqlCmd.Parameters.AddWithValue("@EntryDate", users_Data.EntryDate);
                        sqlCmd.Parameters.AddWithValue("@ExitDate", users_Data.ExitDate);
                        sqlCmd.Parameters.AddWithValue("@ExitTime", users_Data.ExitTime);
                        sqlCmd.Parameters.AddWithValue("@VehicleNo", users_Data.VehicleNo);

                        sqlCmd.ExecuteNonQuery();
                        return RedirectToAction("Update", "Prices");
                    }

                }

               
                    else
                    {
                        ModelState.AddModelError("", "Please fill the required field");
                    }
                
            }

                
            return View(users_Data);
        }

        // GET: Users_Data/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail users_Data = db.UserDetails.Find(id);
            if (users_Data == null)
            {
                return HttpNotFound();
            }

            return View(users_Data);
        }

        // POST: Users_Data/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Location,EntryDate,EntryTime,ExitDate,ExitTime,VehicleNo")] UserDetail users_Data)
        {
            if (ModelState.IsValid)
            {
                db.Entry(users_Data).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(users_Data);
        }

        // GET: Users_Data/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail users_Data = db.UserDetails.Find(id);
            if (users_Data == null)
            {
                return HttpNotFound();
            }
            return View(users_Data);
        }

        // POST: Users_Data/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            UserDetail users_Data = db.UserDetails.Find(id);
            db.UserDetails.Remove(users_Data);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        private bool IsUserExist(string user)
        {
            bool IsUserExist = false;
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                int count = db.UserDetails.Where(a => a.VehicleNo == user).Count();
                if (count > 0)
                {
                    IsUserExist = true;
                }
            }
            return IsUserExist;
        }
        private bool IsEmailExist(string email)
        {
            bool IsEmailExist = false;
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                int count = db.UserDetails.Where(a => a.Email == email).Count();
                if (count > 0)
                {
                    IsEmailExist = true;
                }
            }
            return IsEmailExist;
        }

    }
}
