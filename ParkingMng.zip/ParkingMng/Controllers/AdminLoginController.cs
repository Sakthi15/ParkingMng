﻿using MvcDemoProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MvcDemoProject.Controllers
{
    public class AdminLoginController : Controller
    {
        // GET: AdminLogin
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        //Post:Login 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginViewModel LoginViewModel)
        {
            if (IsAuthenitcatedUser(LoginViewModel.Email, LoginViewModel.Password))
            {
                //MVC and Login Authentication
                FormsAuthentication.SetAuthCookie(LoginViewModel.Email, false);
                return RedirectToAction("Index", "Admin");
            }
            else
            {
                ModelState.AddModelError("", "Your credentail is incorrect");
            }
            return View(LoginViewModel);
        }
        // GET:Register return view
        [HttpGet]
        public ActionResult UserRegistration()
        {
            return View();
        }
        // Post:Register 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserRegistration(RegistrationViewModel RegistrationViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!IsEmailExist(RegistrationViewModel.Email))
                    {
                        using (DemoDataBaseEntities db = new DemoDataBaseEntities())
                        {
                            Admin userobj = new Admin
                            {
                                Email = RegistrationViewModel.Email,
                                
                                //for encryption you should use a strong and secure Algorithm
                                // I'm simply using Base64 for explanation purpose
                                Password = RegistrationViewModel.Password
                               
                            };
                            db.Admins.Add(userobj);
                            if (db.SaveChanges() > 0)
                            {
                                //Set MVC and Login Authentication
                                FormsAuthentication.SetAuthCookie(RegistrationViewModel.Email, false);
                                return RedirectToAction("Login", "AdminLogin");
                            }
                            else
                            {
                                ModelState.AddModelError("", "Something went wrong please try again later!");
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "email already exist please try with diffrent one!");
                    }

                }
                else
                {
                    ModelState.AddModelError("", "Model is Invalid");
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("", e.Message);
            }
            return View();
        }
        public ActionResult SignOut()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Login", "Home");
        }

        private bool IsEmailExist(string email)
        {
            bool IsEmailExist = false;
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                int count = db.Admins.Where(a => a.Email == email).Count();
                if (count > 0)
                {
                    IsEmailExist = true;
                }
            }
            return IsEmailExist;
        }
        private bool IsAuthenitcatedUser(string email, string password)
        {
            var encryptpassowrd =password;
            bool IsValid = false;
            using (DemoDataBaseEntities db = new DemoDataBaseEntities())
            {
                int count = db.Admins.Where(a => a.Email == email && a.Password == encryptpassowrd).Count();
                if (count > 0)
                {
                    IsValid = true;
                }
            }
            return IsValid;
        }
       
    }
}